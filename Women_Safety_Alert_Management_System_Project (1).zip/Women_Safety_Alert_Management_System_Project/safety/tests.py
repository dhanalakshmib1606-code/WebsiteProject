from django.test import TestCase
# Add automated tests for registration, contact ownership and alert creation here.
