from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import EmergencyContact, IncidentReport, SOSAlert

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=150, required=True)
    class Meta:
        model = User
        fields = ["username", "first_name", "email", "password1", "password2"]

class EmergencyContactForm(forms.ModelForm):
    class Meta:
        model = EmergencyContact
        fields = ["name", "phone", "relationship"]
        widgets = {"phone": forms.TextInput(attrs={"pattern": "[0-9+() -]{7,15}"})}

class IncidentReportForm(forms.ModelForm):
    class Meta:
        model = IncidentReport
        fields = ["incident_type", "description", "location"]
        widgets = {"description": forms.Textarea(attrs={"rows": 4})}

class SOSAlertForm(forms.ModelForm):
    class Meta:
        model = SOSAlert
        fields = ["message", "latitude", "longitude"]
        widgets = {
            "message": forms.Textarea(attrs={"rows": 2}),
            "latitude": forms.HiddenInput(),
            "longitude": forms.HiddenInput(),
        }
