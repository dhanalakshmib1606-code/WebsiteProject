from django.db import models
from django.contrib.auth.models import User

class EmergencyContact(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="emergency_contacts")
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    relationship = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.phone})"

class SOSAlert(models.Model):
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("In Progress", "In Progress"),
        ("Resolved", "Resolved"),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sos_alerts")
    latitude = models.CharField(max_length=50, blank=True)
    longitude = models.CharField(max_length=50, blank=True)
    message = models.TextField(default="Emergency! I need assistance.")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Pending")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"SOS #{self.pk} - {self.user.username}"

class IncidentReport(models.Model):
    INCIDENT_CHOICES = [
        ("Harassment", "Harassment"),
        ("Stalking", "Stalking"),
        ("Unsafe Location", "Unsafe Location"),
        ("Other", "Other"),
    ]
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Reviewed", "Reviewed"),
        ("Resolved", "Resolved"),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="incident_reports")
    incident_type = models.CharField(max_length=50, choices=INCIDENT_CHOICES)
    description = models.TextField()
    location = models.CharField(max_length=200)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Pending")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.incident_type} - {self.user.username}"
