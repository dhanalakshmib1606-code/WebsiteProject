from django.contrib import admin
from .models import EmergencyContact, SOSAlert, IncidentReport

@admin.register(EmergencyContact)
class EmergencyContactAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "relationship", "user")
    search_fields = ("name", "phone", "user__username")

@admin.register(SOSAlert)
class SOSAlertAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "status", "created_at")
    list_filter = ("status", "created_at")
    search_fields = ("user__username", "message")

@admin.register(IncidentReport)
class IncidentReportAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "incident_type", "status", "created_at")
    list_filter = ("incident_type", "status")
    search_fields = ("user__username", "location", "description")
