from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("accounts/register/", views.register_view, name="register"),
    path("contacts/", views.contact_list, name="contact_list"),
    path("contacts/add/", views.contact_create, name="contact_create"),
    path("contacts/<int:pk>/edit/", views.contact_edit, name="contact_edit"),
    path("contacts/<int:pk>/delete/", views.contact_delete, name="contact_delete"),
    path("alerts/", views.alert_list, name="alert_list"),
    path("alerts/create/", views.alert_create, name="alert_create"),
    path("incidents/", views.incident_list, name="incident_list"),
    path("incidents/add/", views.incident_create, name="incident_create"),
    path("incidents/<int:pk>/edit/", views.incident_edit, name="incident_edit"),
    path("incidents/<int:pk>/delete/", views.incident_delete, name="incident_delete"),
]
