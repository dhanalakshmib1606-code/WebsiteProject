from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from .forms import RegisterForm, EmergencyContactForm, IncidentReportForm, SOSAlertForm
from .models import EmergencyContact, IncidentReport, SOSAlert

def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account has been created.")
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "registration/register.html", {"form": form})

@login_required
def dashboard(request):
    context = {
        "contact_count": EmergencyContact.objects.filter(user=request.user).count(),
        "alert_count": SOSAlert.objects.filter(user=request.user).count(),
        "incident_count": IncidentReport.objects.filter(user=request.user).count(),
        "recent_alerts": SOSAlert.objects.filter(user=request.user)[:5],
    }
    return render(request, "safety/dashboard.html", context)

@login_required
def contact_list(request):
    query = request.GET.get("q", "").strip()
    contacts = EmergencyContact.objects.filter(user=request.user)
    if query:
        contacts = contacts.filter(Q(name__icontains=query) | Q(phone__icontains=query))
    return render(request, "safety/contact_list.html", {"contacts": contacts, "query": query})

@login_required
def contact_create(request):
    form = EmergencyContactForm(request.POST or None)
    if form.is_valid():
        item = form.save(commit=False)
        item.user = request.user
        item.save()
        messages.success(request, "Emergency contact added.")
        return redirect("contact_list")
    return render(request, "safety/form.html", {"form": form, "title": "Add emergency contact"})

@login_required
def contact_edit(request, pk):
    item = get_object_or_404(EmergencyContact, pk=pk, user=request.user)
    form = EmergencyContactForm(request.POST or None, instance=item)
    if form.is_valid():
        form.save()
        messages.success(request, "Emergency contact updated.")
        return redirect("contact_list")
    return render(request, "safety/form.html", {"form": form, "title": "Edit emergency contact"})

@login_required
def contact_delete(request, pk):
    item = get_object_or_404(EmergencyContact, pk=pk, user=request.user)
    if request.method == "POST":
        item.delete()
        messages.success(request, "Emergency contact deleted.")
        return redirect("contact_list")
    return render(request, "safety/confirm_delete.html", {"item": item, "title": "Delete contact"})

@login_required
def alert_list(request):
    alerts = SOSAlert.objects.filter(user=request.user)
    return render(request, "safety/alert_list.html", {"alerts": alerts})

@login_required
def alert_create(request):
    form = SOSAlertForm(request.POST or None)
    if form.is_valid():
        item = form.save(commit=False)
        item.user = request.user
        item.save()
        messages.warning(request, "SOS alert saved. This demo does not send SMS or contact emergency services.")
        return redirect("alert_list")
    return render(request, "safety/sos_form.html", {"form": form})

@login_required
def incident_list(request):
    query = request.GET.get("q", "").strip()
    reports = IncidentReport.objects.filter(user=request.user)
    if query:
        reports = reports.filter(
            Q(incident_type__icontains=query) |
            Q(description__icontains=query) |
            Q(location__icontains=query)
        )
    return render(request, "safety/incident_list.html", {"reports": reports, "query": query})

@login_required
def incident_create(request):
    form = IncidentReportForm(request.POST or None)
    if form.is_valid():
        item = form.save(commit=False)
        item.user = request.user
        item.save()
        messages.success(request, "Incident report submitted.")
        return redirect("incident_list")
    return render(request, "safety/form.html", {"form": form, "title": "Report an incident"})

@login_required
def incident_edit(request, pk):
    item = get_object_or_404(IncidentReport, pk=pk, user=request.user)
    form = IncidentReportForm(request.POST or None, instance=item)
    if form.is_valid():
        form.save()
        messages.success(request, "Incident report updated.")
        return redirect("incident_list")
    return render(request, "safety/form.html", {"form": form, "title": "Edit incident report"})

@login_required
def incident_delete(request, pk):
    item = get_object_or_404(IncidentReport, pk=pk, user=request.user)
    if request.method == "POST":
        item.delete()
        messages.success(request, "Incident report deleted.")
        return redirect("incident_list")
    return render(request, "safety/confirm_delete.html", {"item": item, "title": "Delete incident report"})
