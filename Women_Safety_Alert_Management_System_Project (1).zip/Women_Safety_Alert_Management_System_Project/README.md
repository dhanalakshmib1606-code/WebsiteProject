# Women Safety Alert Management System

A Django + MySQL full-stack starter project with registration/login/logout, dashboard,
emergency contacts CRUD, SOS alert creation/history, incident reports CRUD, and search.

## Requirements
- Python 3.10+
- MySQL Server
- VS Code (recommended)

## Setup (Windows)
1. Extract the ZIP and open the extracted folder in VS Code.
2. Open Terminal in the folder containing `manage.py`.
3. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. In MySQL Workbench, run:
   ```sql
   CREATE DATABASE women_safety_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
6. Open `women_safety/settings.py` and update `DB_PASSWORD` with your MySQL password.
   You may also set `DB_USER`, `DB_HOST`, and `DB_PORT` if needed.
7. Run migrations:
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```
8. Create an administrator:
   ```bash
   python manage.py createsuperuser
   ```
9. Start the server:
   ```bash
   python manage.py runserver
   ```
10. Open `http://127.0.0.1:8000/`.

## Main URLs
- `/` Home / dashboard (login required)
- `/accounts/register/` Register
- `/accounts/login/` Login
- `/contacts/` Emergency contacts
- `/alerts/` SOS alert history
- `/alerts/create/` Create SOS alert
- `/incidents/` Incident reports
- `/admin/` Django administration

## Important safety limitation
This is an academic demonstration project. Creating an SOS record only stores it in
the database. It does NOT automatically send SMS, call emergency services, or guarantee
that anyone receives the alert. Browser location access requires user permission.
Do not use this demo as a substitute for a real emergency service.
