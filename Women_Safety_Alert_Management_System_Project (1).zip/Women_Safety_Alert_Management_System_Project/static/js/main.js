function getLocation() {
  const status = document.getElementById("locationStatus");
  if (!navigator.geolocation) {
    status.textContent = "Geolocation is not supported by this browser.";
    return;
  }
  status.textContent = "Requesting location permission...";
  navigator.geolocation.getCurrentPosition(
    function(position) {
      document.getElementById("id_latitude").value = position.coords.latitude;
      document.getElementById("id_longitude").value = position.coords.longitude;
      status.textContent = "Location attached to this alert.";
    },
    function() {
      status.textContent = "Location unavailable or permission denied. You can still save the alert.";
    }
  );
}
